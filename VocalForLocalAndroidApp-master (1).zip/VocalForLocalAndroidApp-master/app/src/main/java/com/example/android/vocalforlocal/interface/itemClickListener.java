package com.example.android.vocalforlocal.Interface;

import android.view.View;

public interface itemClickListener {

    void onClick(View view, int position, boolean isLongClick);
}
