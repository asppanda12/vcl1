package com.example.android.vocalforlocal.Prevalent;

import com.example.android.vocalforlocal.Model.Users;

public class Prevalent {
    public  static Users currentOnlineUser;

    public static  final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";

}
